import {contacts} from '../common/Contact';

export default (state = contacts, action) => {
    return state;
};