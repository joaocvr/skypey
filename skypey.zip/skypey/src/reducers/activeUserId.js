export default function activeUserId(state = null, action) {
    return state;
}